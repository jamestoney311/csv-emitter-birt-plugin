package org.eclipse.birt.report.engine.emitter.csv;

public class CSVTags {

	public static final String TAG_COMMA = "," ;
	public static final String TAG_CR = "\n" ;
	
}
